// import { Sequelize, Model, DataTypes } from "sequelize";

// const sequelize = new Sequelize("gany", "root", "63.Sweden", {
//   host: "localhost",
//   dialect: "mysql",
//   dialectOptions: {},
//   define: {
//     freezeTableName: true,
//   },
// });

// const Material = sequelize.define(
//   "material",
//   {
//     name: { type: DataTypes.STRING, allowNull: false },
//     mainCategory: { type: DataTypes.STRING, allowNull: false },
//     subCategory: { type: DataTypes.STRING, allowNull: false },
//     descreption: { type: DataTypes.STRING, allowNull: false },
//     image: { type: DataTypes.STRING, allowNull: true },
//   },
//   {
//     tableName: "material",
//     timestamps: false,
//   }
// );

// export default Material;
